package com.example.gg;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity  implements  View.OnClickListener{

    TextInputLayout regName,regEmail,regPhoneNo,regDrivingL,regCarRegNo,regPassword;
    Button regBtn,regToLoginBtn;

    private FirebaseAuth mAuth;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mAuth = FirebaseAuth.getInstance();

        regName = findViewById(R.id.name);
        regEmail = findViewById(R.id.ename);
        regPhoneNo = findViewById(R.id.phoneNumber);
        regDrivingL = findViewById(R.id.drivingLicence);
        regCarRegNo = findViewById(R.id.carRegistrationNumber);
        regPassword = findViewById(R.id.pass);
        regBtn = findViewById(R.id.reg_btn);
        regToLoginBtn = findViewById(R.id.reg_login_btn);

        regBtn.setOnClickListener(this);
        regToLoginBtn.setOnClickListener(this);




    }

    private Boolean validateName(){
        String val = regName.getEditText().getText().toString();

        if( val.isEmpty()){
            regName.setError("Feild cannot be Empty");
            return false;
        }
        else {
            regName.setError(null);
            regName.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validateEName(){
        String val = regEmail.getEditText().getText().toString();
        String emailPattern = "[a-zA-z0-9._-]+@[a-z]+\\.+[a-z]+";

        if( val.isEmpty()){
            regEmail.setError("Feild cannot be Empty");
            return false;
        }
        else if (!val.matches(emailPattern)) {
            regEmail.setError("Invalid Email address");
            return false;
        }
        else {
            regEmail.setError(null);
            return true;
        }
    }

    private Boolean validatePhoneNo(){
        String val = regPhoneNo.getEditText().getText().toString();

        if( val.isEmpty()){
            regPhoneNo.setError("Feild cannot be Empty");
            return false;
        }
        else {
            regPhoneNo.setError(null);
            return true;
        }
    }
    private Boolean validateDl(){
        String val = regDrivingL.getEditText().getText().toString();

        if( val.isEmpty()){
            regDrivingL.setError("Feild cannot be Empty");
            return false;
        }
        else {
            regDrivingL.setError(null);
            return true;
        }
    }
    private Boolean validateCr(){
        String val = regCarRegNo.getEditText().getText().toString();

        if( val.isEmpty()){
            regCarRegNo.setError("Feild cannot be Empty");
            return false;
        }
        else {
            regCarRegNo.setError(null);
            return true;
        }
    }
    private Boolean validatePassword(){
        String val = regPassword.getEditText().getText().toString();
        String passwprdVal = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{4,}$";

        if( val.isEmpty()){
            regPassword.setError("Feild cannot be Empty");
            return false;
        }
        else if (!val.matches(passwprdVal)) {
            regPassword.setError("Password is too weak");
            return false;
        }
        else {
            regPassword.setError(null);
            return true;
        }
    }



    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.reg_btn:
                registerUser();
                break;
            case R.id.reg_login_btn:
                startActivity(new Intent(this,Login.class));
        }
    }

    private void registerUser() {


            String name = regName.getEditText().getText().toString();
            String ename = regEmail.getEditText().getText().toString();
            String phoneNo = regPhoneNo.getEditText().getText().toString();
            String drivingL = regDrivingL.getEditText().getText().toString();
            String carRegNo = regCarRegNo.getEditText().getText().toString();
            String password = regPassword.getEditText().getText().toString();

        if (!validateName() | !validateEName() | !validatePhoneNo() | !validateDl() | !validateCr() | !validatePassword())
        {
            return;
        }

        mAuth.createUserWithEmailAndPassword(ename,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    User user = new User(name,ename,phoneNo,drivingL,carRegNo);

                    FirebaseDatabase.getInstance().getReference("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                Toast.makeText(SignUp.this,"User has been registered successfully!",Toast.LENGTH_SHORT).show();

                            }
                            else
                            {
                                Toast.makeText(SignUp.this,"Failed to register! Try again",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }else{
                    Toast.makeText(SignUp.this,"Failed To register",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
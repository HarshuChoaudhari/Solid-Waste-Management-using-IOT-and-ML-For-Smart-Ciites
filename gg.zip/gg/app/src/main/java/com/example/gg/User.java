package com.example.gg;

public class User {
    public String name,ename,phoneNo,drivingL,carRegNo;

    public User(){

    }



    public User(String name, String ename, String phoneNo, String drivingL, String carRegNo) {
        this.name = name;
        this.ename = ename;
        this.phoneNo = phoneNo;
        this.drivingL = drivingL;
        this.carRegNo = carRegNo;
    }
}

package com.example.gg;

public class UserHelperClass {

    String name,ename,phoneNo,drivingL,carRegNo ,password;

    public UserHelperClass() {
        this.name = name;
    }

    public UserHelperClass(String name, String ename, String phoneNo, String drivingL, String carRegNo , String password) {
        this.name = name;
        this.ename = ename;
        this.phoneNo = phoneNo;
        this.drivingL = drivingL;
        this.carRegNo  = carRegNo ;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getDrivingL() {
        return drivingL;
    }

    public void setDrivingL(String drivingL) {
        this.drivingL = drivingL;
    }

    public String getCarreg() {
        return carRegNo ;
    }

    public void setCarreg(String carreg) {
        this.carRegNo  = carreg;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
